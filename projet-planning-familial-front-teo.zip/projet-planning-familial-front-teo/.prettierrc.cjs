module.exports = {
	endOfLine: 'auto',
	trailingComma: 'es5',
	semi: true,
	useTabs: false,
	singleQuote: true,
	tabWidth: 2,
	indentStyle: 'space',
};
