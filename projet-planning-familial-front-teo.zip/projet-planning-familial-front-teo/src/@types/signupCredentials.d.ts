export interface SignupCredentialsI {
  email: string;
  password: string;
  passwordConfirm: string;
  firstname: string;
  lastname: string;
}
