export interface SiginCredentialsI {
  emailSignin: string;
  passwordSignin: string;
}
