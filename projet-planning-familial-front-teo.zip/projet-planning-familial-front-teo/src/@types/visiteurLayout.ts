export default interface IvisiteurLayout {
  img: string;
  description: string;
}
