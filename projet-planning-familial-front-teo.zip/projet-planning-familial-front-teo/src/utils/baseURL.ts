const baseURL = import.meta.env.VITE_APP_API_URL_IMG;

export default baseURL;
